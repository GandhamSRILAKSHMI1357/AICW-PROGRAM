# app.py

import streamlit as st
import pickle
import numpy as np

# Load trained model
with open("wine_model.pkl", "rb") as f:
    model = pickle.load(f)

# Set background image
def set_bg_image(image_file):
    with open(image_file, "rb") as img:
        encoded = base64.b64encode(img.read()).decode()

    st.markdown(
        f"""
        <style>
        .stApp {{
            background-image: url("data:image/jpg;base64,{encoded}");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

# Call function
set_bg_image("background.jpg")

# App Title
st.title("🍷 Wine Classification App")

st.write("Enter the wine features to predict the class of wine.")

# Input features
fixed_acidity = st.number_input("Fixed Acidity", min_value=0.0, max_value=20.0, value=7.0)
volatile_acidity = st.number_input("Volatile Acidity", min_value=0.0, max_value=5.0, value=0.7)
citric_acid = st.number_input("Citric Acid", min_value=0.0, max_value=5.0, value=0.0)
residual_sugar = st.number_input("Residual Sugar", min_value=0.0, max_value=20.0, value=1.9)
chlorides = st.number_input("Chlorides", min_value=0.0, max_value=1.0, value=0.076)
free_sulfur_dioxide = st.number_input("Free Sulfur Dioxide", min_value=0.0, max_value=100.0, value=11.0)
total_sulfur_dioxide = st.number_input("Total Sulfur Dioxide", min_value=0.0, max_value=200.0, value=34.0)
density = st.number_input("Density", min_value=0.9, max_value=1.1, value=0.9978)
pH = st.number_input("pH", min_value=0.0, max_value=14.0, value=3.51)
sulphates = st.number_input("Sulphates", min_value=0.0, max_value=5.0, value=0.56)
alcohol = st.number_input("Alcohol", min_value=0.0, max_value=20.0, value=9.4)

# Predict button
if st.button("Predict Wine Class"):
    features = np.array([fixed_acidity, volatile_acidity, citric_acid, residual_sugar,
                         chlorides, free_sulfur_dioxide, total_sulfur_dioxide,
                         density, pH, sulphates, alcohol]).reshape(1, -1)
    
    prediction = model.predict(features)[0]
    
    wine_classes = ["Class 0", "Class 1", "Class 2"]
    st.success(f"The predicted wine class is: {wine_classes[prediction]}")
