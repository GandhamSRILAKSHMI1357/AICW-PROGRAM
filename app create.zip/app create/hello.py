# import streamlit
import streamlit as st

#title
st.title('Hello,world! Welcome to AICW program💕')

#header
st.header("Header in Streamlit")

#subheader
st.subheader("Subheader in Streamlit")